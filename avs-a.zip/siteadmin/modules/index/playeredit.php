<?php
defined('_VALID') or die('Restricted Access!');
Auth::checkAdmin();

$profile_id = ( isset($_GET['PID']) && is_numeric($_GET['PID']) ) ? intval($_GET['PID']) : NULL;
if ( !$profile_id ) {
    $errors[] = 'Player profile id not valid or not set!';
}
$player = array();
$sql    = "SELECT * FROM player WHERE id = " .$profile_id. " LIMIT 1";
$rs     = $conn->execute($sql);
if ( $conn->Affected_Rows() == '1' ) {
    $player = $rs->getrows();
    $player = $player['0'];
	$player['mail_color'] = strtoupper(str_replace('0x', '', $player['mail_color']));
	$player['related_color'] = strtoupper(str_replace('0x', '', $player['related_color']));
	$player['replay_color'] = strtoupper(str_replace('0x', '', $player['replay_color']));	
	$player['embed_color'] = strtoupper(str_replace('0x', '', $player['embed_color']));	
	$player['copy_color'] = strtoupper(str_replace('0x', '', $player['copy_color']));	
	$player['time_color'] = strtoupper(str_replace('0x', '', $player['time_color']));	
	$player['share_color'] = strtoupper(str_replace('0x', '', $player['share_color']));	
	$player['adv_nav_color'] = strtoupper(str_replace('0x', '', $player['adv_nav_color']));	
	$player['adv_title_color'] = strtoupper(str_replace('0x', '', $player['adv_title_color']));	
	$player['adv_body_color'] = strtoupper(str_replace('0x', '', $player['adv_body_color']));	
	$player['adv_link_color'] = strtoupper(str_replace('0x', '', $player['adv_link_color']));			
} else {
    $errors[]    = 'Failed to load default player profile!';
}

$skins  = get_player_skins();

if ( isset($_POST['submit_settings']) && !$errors ) {
	$filter				= new VFilter();
    $autorun            = $filter->process($_POST['autorun']);
    $buffertime         = intval($_POST['buffertime']);
    $buttons            = intval($_POST['buttons']);
    $replay             = intval($_POST['replay']);
    $related            = intval($_POST['related']);
    $related_content    = $filter->process($_POST['related_content']);
    $share              = intval($_POST['share']);
    $mail               = intval($_POST['mail']);
    $embed              = intval($_POST['embed']);
    $text_adv           = intval($_POST['text_adv']);
    $text_adv_type      = $filter->process($_POST['text_adv_type']);
    $text_adv_delay     = intval($_POST['text_adv_delay']);
    $video_adv          = intval($_POST['video_adv']);
    $video_adv_type     = $filter->process($_POST['video_adv_type']);
    $video_adv_position = $filter->process($_POST['video_adv_position']);
    $skin               = $filter->process($_POST['skin']);
    $mail_color         = $filter->process($_POST['mail_color']);
    $related_color      = $filter->process($_POST['related_color']);
    $replay_color       = $filter->process($_POST['replay_color']);
    $copy_color         = $filter->process($_POST['copy_color']);
    $embed_color        = $filter->process($_POST['embed_color']);
    $time_color         = $filter->process($_POST['time_color']);
    $share_color		= $filter->process($_POST['share_color']);
    $adv_nav_color      = $filter->process($_POST['adv_nav_color']);
    $adv_body_color     = $filter->process($_POST['adv_body_color']);
    $adv_title_color    = $filter->process($_POST['adv_title_color']);
    $adv_link_color     = $filter->process($_POST['adv_link_color']);

	// player rebranding
    $logo_url           = $filter->process($_POST['logo_url']);
    $logo_link          = $filter->process($_POST['logo_link']);
    $logo_position      = $filter->process($_POST['logo_position']);
    $logo_alpha         = intval($_POST['logo_alpha']);

    if ( $buffertime == '0' ) {
        $errors[] = 'Please enter a value greater then 0 for the player buffertime!';
		$err['buffertime'] = 1;
    }
    
    if ( $text_adv_delay == '0' ) {
        $errors[] = 'Please enter a value greater then 0 for the player text advertising delay!';
		$err['text_adv_delay'] = 1;
    }
    
    if ( !$errors ) {
        $autorun    = ( $autorun == 'true' ) ? 'true' : 'false';
        $buttons    = ( $buttons == '0' ) ? 0 : 1;
        $replay     = ( $replay == '0' ) ? 0 : 1;
        $related    = ( $related == '0' ) ? 0 : 1;
        $share      = ( $share == '0' ) ? 0 : 1;
        $mail       = ( $mail == '0' ) ? 0 : 1;
        $embed      = ( $embed == '0' ) ? 0 : 1;
        $text_adv   = ( $text_adv == '0' ) ? 0 : 1;
        $video_adv  = ( $video_adv == '0' ) ? 0 : 1;
        
        $sql    = "UPDATE player SET autorun = '" .$autorun. "', buttons = '" .$buttons. "', buffertime = '" .$buffertime. "',
                                              replay = '" .$replay. "', share = '" .$share. "', mail = '" .$mail. "', embed = '" .$embed. "',
                                              related = '" .$related. "', related_content = '" .mysql_real_escape_string($related_content). "', skin = '" .mysql_real_escape_string($skin). "',
                                              text_adv = '" .$text_adv. "', text_adv_type = '" .mysql_real_escape_string($text_adv_type). "', text_adv_delay = '" .$text_adv_delay. "',
                                              video_adv = '" .$video_adv. "', video_adv_type = '" .mysql_real_escape_string($video_adv_type). "', video_adv_position = '" .mysql_real_escape_string($video_adv_position). "',
                                              mail_color = '0x" .mysql_real_escape_string($mail_color). "', related_color = '0x" .mysql_real_escape_string($related_color). "', 
                                              replay_color = '0x" .mysql_real_escape_string($replay_color). "', embed_color = '0x" .mysql_real_escape_string($embed_color). "', 
                                              copy_color = '0x" .mysql_real_escape_string($copy_color). "', time_color = '0x" .mysql_real_escape_string($time_color). "',
					      share_color = '0x" .mysql_real_escape_string($share_color). "', adv_nav_color = '0x" .mysql_real_escape_string($adv_nav_color). "',
					      adv_title_color = '0x" .mysql_real_escape_string($adv_title_color). "', adv_body_color = '0x" .mysql_real_escape_string($adv_body_color). "',
					      adv_link_color = '0x" .mysql_real_escape_string($adv_link_color). "',
						  logo_url = '" .mysql_real_escape_string($logo_url). "', logo_link = '" .mysql_real_escape_string($logo_link). "', 
                          logo_position = '" .mysql_real_escape_string($logo_position). "', logo_alpha = '" .$logo_alpha. "' 
                   WHERE status = '1' LIMIT 1";
        $conn->execute($sql);
        $messages[] = 'Default video player profile updated!';
		$player['autorun']            = $autorun;
		$player['buffertime']         = $buffertime;
		$player['buttons']            = $buttons;
		$player['replay']             = $replay;
		$player['related']            = $related;
		$player['related_content']    = $related_content;
		$player['share']              = $share;
		$player['mail']               = $mail;
		$player['embed']              = $embed;
		$player['text_adv']           = $text_adv;
		$player['text_adv_type']      = $text_adv_type;
		$player['text_adv_delay']     = $text_adv_delay;
		$player['video_adv']          = $video_adv;
		$player['video_adv_type']     = $video_adv_type;
		$player['video_adv_position'] = $video_adv_position;
		$player['skin']               = $skin;
		$player['mail_color']         = $mail_color;
		$player['related_color']      = $related_color;
		$player['replay_color']       = $replay_color;
		$player['copy_color']         = $copy_color;
		$player['embed_color']        = $embed_color;
		$player['time_color']         = $time_color;
		$player['share_color']		  = $share_color;
		$player['adv_nav_color']      = $adv_nav_color;
		$player['adv_body_color']     = $adv_body_color;
		$player['adv_title_color']    = $adv_title_color;
		$player['adv_link_color']     = $adv_link_color;
		$player['logo_url']           = $logo_url;
		$player['logo_link']          = $logo_link;
		$player['logo_position']      = $logo_position;
		$player['logo_alpha']         = $logo_alpha;
    } else {
		$player['autorun']            = $autorun;
		$player['buffertime']         = $buffertime;
		$player['buttons']            = $buttons;
		$player['replay']             = $replay;
		$player['related']            = $related;
		$player['related_content']    = $related_content;
		$player['share']              = $share;
		$player['mail']               = $mail;
		$player['embed']              = $embed;
		$player['text_adv']           = $text_adv;
		$player['text_adv_type']      = $text_adv_type;
		$player['text_adv_delay']     = $text_adv_delay;
		$player['video_adv']          = $video_adv;
		$player['video_adv_type']     = $video_adv_type;
		$player['video_adv_position'] = $video_adv_position;
		$player['skin']               = $skin;
		$player['mail_color']         = $mail_color;
		$player['related_color']      = $related_color;
		$player['replay_color']       = $replay_color;
		$player['copy_color']         = $copy_color;
		$player['embed_color']        = $embed_color;
		$player['time_color']         = $time_color;
		$player['share_color']		  = $share_color;
		$player['adv_nav_color']      = $adv_nav_color;
		$player['adv_body_color']     = $adv_body_color;
		$player['adv_title_color']    = $adv_title_color;
		$player['adv_link_color']     = $adv_link_color;
		$player['logo_url']           = $logo_url;
		$player['logo_link']          = $logo_link;
		$player['logo_position']      = $logo_position;
		$player['logo_alpha']         = $logo_alpha;
	}
}

$smarty->assign('err', $err);
$smarty->assign('skins', $skins);
$smarty->assign('player', $player);
?>
