<?php
defined('_VALID') or die('Restricted Access!');

Auth::checkAdmin();

$phppath    = $config['phppath'];
$mplayer    = $config['mplayer'];
$mencoder   = $config['mencoder'];
$ffmpeg     = $config['ffmpeg'];
$metainject = $config['metainject'];
$yamdi      = $config['yamdi'];
$mp4box     = $config['mp4box'];
$mediainfo  = $config['mediainfo'];
$neroaacenc = $config['neroaacenc'];

if ( file_exists($phppath) && is_file($phppath) && is_executable($phppath) ) {
	$binaries['phppath'] = '1';
} else {
	if ( file_exists('/usr/local/bin/php') && is_file('/usr/local/bin/php') && is_executable('/usr/local/bin/php') ) {
		$binaries['phppath'] = '/usr/local/bin/php';
	} else {
		if ( file_exists('/usr/bin/php') && is_file('/usr/bin/php') && is_executable('/usr/bin/php') ) {
			$binaries['phppath'] = '/usr/bin/php';
		}
	}
}

if ( file_exists($mplayer) && is_file($mplayer) && is_executable($mplayer) ) {
	$binaries['mplayer'] = '1';
} else {
	if ( file_exists('/usr/local/bin/mplayer') && is_file('/usr/local/bin/mplayer') && is_executable('/usr/local/bin/mplayer') ) {
		$binaries['mplayer'] = '/usr/local/bin/mplayer';
	} else {
		if ( file_exists('/usr/bin/mplayer') && is_file('/usr/bin/mplayer') && is_executable('/usr/bin/mplayer') ) {
			$binaries['mplayer'] = '/usr/bin/mplayer';
		}
	}
}

if ( file_exists($mencoder) && is_file($mencoder) && is_executable($mencoder) ) {
	$binaries['mencoder'] = '1';
} else {
	if ( file_exists('/usr/local/bin/mencoder') && is_file('/usr/local/bin/mencoder') && is_executable('/usr/local/bin/mencoder') ) {
		$binaries['mencoder'] = '/usr/local/bin/mencoder';
	} else {
		if ( file_exists('/usr/bin/mencoder') && is_file('/usr/bin/mencoder') && is_executable('/usr/bin/mencoder') ) {
			$binaries['mencoder'] = '/usr/bin/mencoder';
		}
	}
}

if ( file_exists($ffmpeg) && is_file($ffmpeg) && is_executable($ffmpeg) ) {
	$binaries['ffmpeg'] = '1';
} else {
	if ( file_exists('/usr/local/bin/ffmpeg') && is_file('/usr/local/bin/ffmpeg') && is_executable('/usr/local/bin/ffmpeg') ) {
		$binaries['ffmpeg'] = '/usr/local/bin/ffmpeg';
	} else {
		if ( file_exists('/usr/bin/ffmpeg') && is_file('/usr/bin/ffmpeg') && is_executable('/usr/bin/ffmpeg') ) {
			$binaries['ffmpeg'] = '/usr/bin/ffmpeg';
		}
	}
}

if ( file_exists($metainject) && is_file($metainject) && is_executable($metainject) ) {
	$binaries['metainject'] = '1';
} else {
	if ( file_exists('/usr/local/bin/flvtool2') && is_file('/usr/local/bin/flvtool2') && is_executable('/usr/local/bin/flvtool2') ) {
		$binaries['metainject'] = '/usr/local/bin/flvtool2';
	} else {
		if ( file_exists('/usr/bin/flvtool2') && is_file('/usr/bin/flvtool2') && is_executable('/usr/bin/flvtool2') ) {
			$binaries['metainject'] = '/usr/bin/flvtool2';
		}
	}
}	

if ( file_exists($yamdi) && is_file($yamdi) && is_executable($yamdi) ) {
	$binaries['yamdi'] = '1';
} else {
	if ( file_exists('/usr/local/bin/yamdi') && is_file('/usr/local/bin/yamdi') && is_executable('/usr/local/bin/yamdi') ) {
		$binaries['yamdi'] = '/usr/local/bin/yamdi';
	} else {
		if ( file_exists('/usr/bin/yamdi') && is_file('/usr/bin/yamdi') && is_executable('/usr/bin/yamdi') ) {
			$binaries['yamdi'] = '/usr/bin/yamdi';
		}
	}
}

if ( file_exists($mp4box) && is_file($mp4box) && is_executable($mp4box) ) {
	$binaries['mp4box'] = '1';
} else {
	if ( file_exists('/usr/local/bin/MP4Box') && is_file('/usr/local/bin/MP4Box') && is_executable('/usr/local/bin/MP4Box') ) {
		$binaries['mp4box'] = '/usr/local/bin/MP4Box';
	} else {
		if ( file_exists('/usr/bin/MP4Box') && is_file('/usr/bin/MP4Box') && is_executable('/usr/bin/MP4Box') ) {
			$binaries['mp4box'] = '/usr/bin/MP4Box';
		}
	}
}

if ( file_exists($neroaacenc) && is_file($neroaacenc) && is_executable($neroaacenc) ) {
	$binaries['neroaacenc'] = '1';
} else {
	if ( file_exists('/usr/local/bin/neroAacEnc') && is_file('/usr/local/bin/neroAacEnc') && is_executable('/usr/local/bin/neroAacEnc') ) {
		$binaries['neroaacenc'] = '/usr/local/bin/neroAacEnc';
	} else {
		if ( file_exists('/usr/bin/neroAacEnc') && is_file('/usr/bin/neroAacEnc') && is_executable('/usr/bin/neroAacEnc') ) {
			$binaries['neroaacenc'] = '/usr/bin/neroAacEnc';
		}
	}
}	

if ( file_exists($mediainfo) && is_file($mediainfo) && is_executable($mediainfo) ) {
	$binaries['mediainfo'] = '1';
} else {
	if ( file_exists('/usr/local/bin/mediainfo') && is_file('/usr/local/bin/mediainfo') && is_executable('/usr/local/bin/mediainfo') ) {
		$binaries['mediainfo'] = '/usr/local/bin/mediainfo';
	} else {
		if ( file_exists('/usr/bin/mediainfo') && is_file('/usr/bin/mediainfo') && is_executable('/usr/bin/mediainfo') ) {
			$binaries['mediainfo'] = '/usr/bin/mediainfo';
		}
	}
}

if ( isset($_POST['submit_media']) ) {
    $filter                     = new VFilter();
    $phppath			        = $filter->get('phppath');
	$mencoder			        = $filter->get('mencoder');
	$mplayer			        = $filter->get('mplayer');
	$ffmpeg				        = $filter->get('ffmpeg');
	$metainject			        = $filter->get('metainject');
    $yamdi                      = $filter->get('yamdi');
	$thumbs_tool			    = $filter->get('thumbs_tool');
    $meta_tool                  = $filter->get('meta_tool');
 	//--mod--
 	$mp4box			    		= $filter->get('mp4box');
    $neroaacenc					= $filter->get('neroaacenc');
    $mediainfo			    	= $filter->get('mediainfo');
 	//--end--   
	$img_max_width			    = $filter->get('img_max_width', 'INTEGER');
	$img_max_height			    = $filter->get('img_max_height', 'INTEGER');
	$video_max_size			    = $filter->get('video_max_size', 'INTEGER');
	$video_allowed_extensions	= $filter->get('video_allowed_extensions');
    $video_allowed_extensions   = str_replace(' ', '', $video_allowed_extensions);
    $video_allowed_extensions   = str_replace("\r", '', $video_allowed_extensions);
    $video_allowed_extensions   = str_replace("\n", '', $video_allowed_extensions);
	$post_max_size			    = str_replace('M', '', ini_get('post_max_size'));
	$upload_max_filesize		= str_replace('M', '', ini_get('upload_max_filesize'));

	$thumbnail_player_width     = $filter->get('thumbnail_player_width', 'INTEGER');
	$thumbnail_player_height    = $filter->get('thumbnail_player_height', 'INTEGER');
	$thumbnail_remove_bb        = $filter->get('thumbnail_remove_bb');
	$thumbnail_keep_ar          = $filter->get('thumbnail_keep_ar');
	
	if ($thumbnail_remove_bb != '1') {
		$thumbnail_remove_bb = 0;
	} else {
		$thumbnail_remove_bb = 1;
	}

	if ($thumbnail_keep_ar != '1') {
		$thumbnail_keep_ar = 0;
	} else {
		$thumbnail_keep_ar = 1;
	}
    
	if ( $phppath == '' ) {
		$errors[] = 'Path to PHP CLI binary cannot be left blank!';
		$err['phppath'] = 1;
	}
	if ( $mencoder == '' ) {
		$errors[] = 'Path to Mencoder binary cannot be left blank!';
		$err['mencoder'] = 1;
	}
	if ( $ffmpeg == '' ) {
		$errors[] = 'Path to FFMpeg binary cannot be left blank!';
		$err['ffmpeg'] = 1;		
	}
	if ( $mplayer == '' ) {
		$errors[] = 'Path to MPlayer binary cannot be left blank!';
		$err['mplayer'] = 1;		
	}
	if ( $metainject == '' && $meta_tool == 'flvtool2' ) {
		$errors[] = 'Path to FLVTool2 binary cannot be left blank!';
		$err['metainject'] = 1;		
	}
	if ( $yamdi == '' && $meta_tool == 'yamdi' ) {
		$errors[] = 'Path to Yamdi binary cannot be left blank!';
		$err['yamdi'] = 1;		
	}
	if ( $mp4box == '' ) {
		$errors[] = 'Path to MP4Box binary cannot be left blank!';
		$err['mp4box'] = 1;		
	}	
	if ( $neroaacenc == '' ) {
		$errors[] = 'Path to NeroAccEnc binary cannot be left blank!';
		$err['neroaacenc'] = 1;		
	}
		if ( $mediainfo == '' ) {
		$errors[] = 'Path to Mediainfo Path binary cannot be left blank!';
		$err['mediainfo'] = 1;		
	}
	if ( $img_max_width == '' ) {
		$errors[] = 'Max Thumbnail Width (in pixels) cannot be left blank!';
		$err['img_max_width'] = 1;		
	}
	elseif ( !is_numeric($img_max_width) ) {
		$errors[] = 'Max Thumbnail Width (in pixels) must have a numeric value!';		
		$err['img_max_width'] = 1;		
	}
	if ( $img_max_height == '' ) {
		$errors[] = 'Max Thumbnail Height (in pixels) cannot be left blank!';
		$err['img_max_height'] = 1;		
	}
	elseif ( !is_numeric($img_max_height) ) {
		$errors[] = 'Max Thumbnail Height (in pixels) must have a numeric value!';
		$err['img_max_height'] = 1;		
	}
	if ( $video_max_size == '' ) {
		$errors[] = 'Video Max Size field cannot be blank!';
		$err['video_max_size'] = 1;		
	} else {
		settype($video_max_size, 'integer');
		settype($post_max_size, 'integer');
		settype($upload_max_filesize, 'integer');
		if ( $video_max_size > $post_max_size || $video_max_size > $upload_max_filesize ) {
			$errors[] = 'Video Max Size cannot be bigger then the php values for \'post_max_size\' or \'upload_max_filesize\'.<br> Please edit php settings (php.ini) and increase the post_max_size and upload_max_filesize values!';
			$err['video_max_size'] = 1;			
		}
	}
	if ( $video_allowed_extensions == '' ) {
		$errors[] = 'Video Allowed Extensions field cannot be empty!';
		$err['video_allowed_extensions'] = 1;		
	}
	elseif ( !preg_match('/^[a-zA-Z0-9, ]*$/', $video_allowed_extensions) ) {
		$errors[] = 'Video Allowed Extensions field can only contain alpha-numeric characters, comas and spaces!';
		$err['video_allowed_extensions'] = 1;		
	}
	else {
		$video_allowed_extensions = str_replace(' ', '', $video_allowed_extensions);
	}

	if ( $thumbnail_player_width == '' ) {
		$errors[] = 'Thumbnail Player Width (in pixels) cannot be left blank!';
		$err['thumbnail_player_width'] = 1;		
	}
	elseif ( !is_numeric($thumbnail_player_width) ) {
		$errors[] = 'Thumbnail Player Width (in pixels) must have a numeric value!';		
		$err['thumbnail_player_width'] = 1;		
	}
	if ( $thumbnail_player_height == '' ) {
		$errors[] = 'Thumbnail Player Height (in pixels) cannot be left blank!';
		$err['thumbnail_player_height'] = 1;		
	}
	elseif ( !is_numeric($thumbnail_player_height) ) {
		$errors[] = 'Thumbnail Player Height (in pixels) must have a numeric value!';		
		$err['thumbnail_player_height'] = 1;		
	}	
	
	if ( !$errors ) {
        $config['phppath']                   = $phppath;
        $config['mplayer']                   = $mplayer;
        $config['mencoder']                  = $mencoder;
        $config['ffmpeg']                    = $ffmpeg;
        $config['metainject']                = $metainject;
        $config['yamdi']                     = $yamdi;
        $config['thumbs_tool']               = $thumbs_tool;
        $config['meta_tool']                 = $meta_tool;
        $config['img_max_width']             = $img_max_width;
        $config['img_max_height']            = $img_max_height;
        $config['video_max_size']            = $video_max_size;
        //--mod--
        $config['mp4box']                   = $mp4box;
		$config['mediainfo']                = $mediainfo;
		$config['neroaacenc']               = $neroaacenc;
        //--end--
        $config['video_allowed_extensions'] = $video_allowed_extensions;

		$config['thumbnail_player_width']   = $thumbnail_player_width;
		$config['thumbnail_player_height']  = $thumbnail_player_height;
		$config['thumbnail_remove_bb']      = $thumbnail_remove_bb;
		$config['thumbnail_keep_ar']        = $thumbnail_keep_ar;
		
		update_config($config);
        update_smarty();
		$messages[] = 'Conversion settings updated successfully!';
	}
	
	if ( file_exists($phppath) && is_file($phppath) && is_executable($phppath) ) {
		$binaries['phppath'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/php') && is_file('/usr/local/bin/php') && is_executable('/usr/local/bin/php') ) {
			$binaries['phppath'] = '/usr/local/bin/php';
		} else {
			if ( file_exists('/usr/bin/php') && is_file('/usr/bin/php') && is_executable('/usr/bin/php') ) {
				$binaries['phppath'] = '/usr/bin/php';
			}
		}
	}
	
	if ( file_exists($mplayer) && is_file($mplayer) && is_executable($mplayer) ) {
		$binaries['mplayer'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/mplayer') && is_file('/usr/local/bin/mplayer') && is_executable('/usr/local/bin/mplayer') ) {
			$binaries['mplayer'] = '/usr/local/bin/mplayer';
		} else {
			if ( file_exists('/usr/bin/mplayer') && is_file('/usr/bin/mplayer') && is_executable('/usr/bin/mplayer') ) {
				$binaries['mplayer'] = '/usr/bin/mplayer';
			}
		}
	}
	
	if ( file_exists($mencoder) && is_file($mencoder) && is_executable($mencoder) ) {
		$binaries['mencoder'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/mencoder') && is_file('/usr/local/bin/mencoder') && is_executable('/usr/local/bin/mencoder') ) {
			$binaries['mencoder'] = '/usr/local/bin/mencoder';
		} else {
			if ( file_exists('/usr/bin/mencoder') && is_file('/usr/bin/mencoder') && is_executable('/usr/bin/mencoder') ) {
				$binaries['mencoder'] = '/usr/bin/mencoder';
			}
		}
	}
	
	if ( file_exists($ffmpeg) && is_file($ffmpeg) && is_executable($ffmpeg) ) {
		$binaries['ffmpeg'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/ffmpeg') && is_file('/usr/local/bin/ffmpeg') && is_executable('/usr/local/bin/ffmpeg') ) {
			$binaries['ffmpeg'] = '/usr/local/bin/ffmpeg';
		} else {
			if ( file_exists('/usr/bin/ffmpeg') && is_file('/usr/bin/ffmpeg') && is_executable('/usr/bin/ffmpeg') ) {
				$binaries['ffmpeg'] = '/usr/bin/ffmpeg';
			}
		}
	}
	
	if ( file_exists($metainject) && is_file($metainject) && is_executable($metainject) ) {
		$binaries['metainject'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/flvtool2') && is_file('/usr/local/bin/flvtool2') && is_executable('/usr/local/bin/flvtool2') ) {
			$binaries['metainject'] = '/usr/local/bin/flvtool2';
		} else {
			if ( file_exists('/usr/bin/flvtool2') && is_file('/usr/bin/flvtool2') && is_executable('/usr/bin/flvtool2') ) {
				$binaries['metainject'] = '/usr/bin/flvtool2';
			}
		}
	}	

	if ( file_exists($yamdi) && is_file($yamdi) && is_executable($yamdi) ) {
		$binaries['yamdi'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/yamdi') && is_file('/usr/local/bin/yamdi') && is_executable('/usr/local/bin/yamdi') ) {
			$binaries['yamdi'] = '/usr/local/bin/yamdi';
		} else {
			if ( file_exists('/usr/bin/yamdi') && is_file('/usr/bin/yamdi') && is_executable('/usr/bin/yamdi') ) {
				$binaries['yamdi'] = '/usr/bin/yamdi';
			}
		}
	}

	if ( file_exists($mp4box) && is_file($mp4box) && is_executable($mp4box) ) {
		$binaries['mp4box'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/MP4Box') && is_file('/usr/local/bin/MP4Box') && is_executable('/usr/local/bin/MP4Box') ) {
			$binaries['mp4box'] = '/usr/local/bin/MP4Box';
		} else {
			if ( file_exists('/usr/bin/MP4Box') && is_file('/usr/bin/MP4Box') && is_executable('/usr/bin/MP4Box') ) {
				$binaries['mp4box'] = '/usr/bin/MP4Box';
			}
		}
	}
	
	if ( file_exists($neroaacenc) && is_file($neroaacenc) && is_executable($neroaacenc) ) {
		$binaries['neroaacenc'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/neroAacEnc') && is_file('/usr/local/bin/neroAacEnc') && is_executable('/usr/local/bin/neroAacEnc') ) {
			$binaries['neroaacenc'] = '/usr/local/bin/neroAacEnc';
		} else {
			if ( file_exists('/usr/bin/neroAacEnc') && is_file('/usr/bin/neroAacEnc') && is_executable('/usr/bin/neroAacEnc') ) {
				$binaries['neroaacenc'] = '/usr/bin/neroAacEnc';
			}
		}
	}	
	
	if ( file_exists($mediainfo) && is_file($mediainfo) && is_executable($mediainfo) ) {
		$binaries['mediainfo'] = '1';
	} else {
		if ( file_exists('/usr/local/bin/mediainfo') && is_file('/usr/local/bin/mediainfo') && is_executable('/usr/local/bin/mediainfo') ) {
			$binaries['mediainfo'] = '/usr/local/bin/mediainfo';
		} else {
			if ( file_exists('/usr/bin/mediainfo') && is_file('/usr/bin/mediainfo') && is_executable('/usr/bin/mediainfo') ) {
				$binaries['mediainfo'] = '/usr/bin/mediainfo';
			}
		}
	}
	
	$smarty->assign('err', $err);	
	$smarty->assign('phppath', $phppath);
	$smarty->assign('mencoder', $mencoder);
	$smarty->assign('mplayer', $mplayer);
	$smarty->assign('ffmpeg', $ffmpeg);
	$smarty->assign('metainject', $metainject);
	$smarty->assign('yamdi', $yamdi);
	$smarty->assign('thumbs_tool', $thumbs_tool);
	$smarty->assign('meta_tool', $meta_tool);
	$smarty->assign('mp4box', $mp4box);
	$smarty->assign('neroaacenc', $neroaacenc);
	$smarty->assign('mediainfo', $mediainfo);
	$smarty->assign('img_max_width', $img_max_width);
	$smarty->assign('img_max_height', $img_max_height);
	$smarty->assign('video_max_size', $video_max_size);
	$smarty->assign('video_allowed_extensions', $video_allowed_extensions);	

}
$smarty->assign('binaries', $binaries);
?>
