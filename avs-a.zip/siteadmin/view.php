<?php
define('_VALID', true);
define('_ADMIN', true);
require '../include/config.php';
require '../include/function_global.php';
require '../include/function_admin.php';
require '../include/function_smarty.php';
require '../classes/auth.class.php';

if (isset($_GET['VID']) && $_GET['VID'] != '') {
	$vid = intval($_GET['VID']);
} else {
	die();
}

$sql = "SELECT * from video WHERE VID = '" .mysql_real_escape_string($vid). "' LIMIT 1";
$rs = $conn->execute($sql);

if ( $conn->Affected_Rows() == 1 ) {
	$video = $rs->getrows();
	$video = $video[0];
} else {
	die();
}

$smarty->assign('video', $video);
$smarty->display('video_vplayer.tpl');
?>
