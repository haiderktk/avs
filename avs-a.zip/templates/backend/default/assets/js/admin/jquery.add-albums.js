$(document).ready(function(){

	$("#category").select2();
	//$("#category").select2 ('container').find ('.select2-search').addClass ('hidden');

});