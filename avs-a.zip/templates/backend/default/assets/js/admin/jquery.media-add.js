$(document).ready(function(){
	$("#adv_channel").select2(); 
});